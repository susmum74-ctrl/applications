import { Users, Award, Zap, HeadphonesIcon } from 'lucide-react';

function WhyChooseUs() {
  const reasons = [
    {
      icon: Users,
      title: 'Expert Team',
      description: 'Our certified professionals bring years of industry experience and technical expertise.',
    },
    {
      icon: Award,
      title: 'Proven Track Record',
      description: 'Hundreds of successful projects delivered on time and within budget.',
    },
    {
      icon: Zap,
      title: 'Rapid Deployment',
      description: 'Agile methodologies ensure quick turnaround without compromising quality.',
    },
    {
      icon: HeadphonesIcon,
      title: '24/7 Support',
      description: 'Round-the-clock technical support to keep your systems running smoothly.',
    },
  ];

  return (
    <section className="py-24 bg-gradient-to-br from-blue-600 to-cyan-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-white mb-4">
            Why Choose Us
          </h2>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Partner with a team that's committed to your success
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {reasons.map((reason, index) => {
            const Icon = reason.icon;
            return (
              <div
                key={index}
                className="bg-white bg-opacity-10 backdrop-blur-lg rounded-xl p-8 hover:bg-opacity-20 transition-all duration-300"
              >
                <div className="bg-white bg-opacity-20 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                  <Icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{reason.title}</h3>
                <p className="text-blue-100 leading-relaxed">{reason.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export default WhyChooseUs;
