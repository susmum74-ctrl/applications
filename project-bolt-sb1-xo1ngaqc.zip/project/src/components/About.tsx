import { CheckCircle2 } from 'lucide-react';

function About() {
  const achievements = [
    '15+ Years of Excellence',
    '500+ Successful Projects',
    '98% Client Satisfaction',
    '24/7 Support',
  ];

  const values = [
    'Innovation-driven approach to problem-solving',
    'Commitment to quality and excellence',
    'Transparent communication and collaboration',
    'Continuous learning and improvement',
  ];

  return (
    <section id="about" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              About TechSolutions
            </h2>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              We are a leading IT service provider dedicated to helping businesses navigate the complex world of technology. With over 15 years of experience, we've been at the forefront of digital innovation.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Our team of expert engineers, developers, and consultants work closely with clients to deliver customized solutions that drive growth, efficiency, and competitive advantage.
            </p>

            <div className="space-y-4 mb-8">
              {values.map((value, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <CheckCircle2 className="h-6 w-6 text-blue-600 flex-shrink-0 mt-1" />
                  <p className="text-gray-700">{value}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="grid grid-cols-2 gap-6">
                {achievements.map((achievement, index) => (
                  <div key={index} className="text-center">
                    <div className="bg-blue-50 rounded-lg p-6">
                      <p className="text-sm font-semibold text-blue-600 mb-2">
                        {achievement.split(' ')[0]}
                      </p>
                      <p className="text-gray-700 text-sm font-medium">
                        {achievement.split(' ').slice(1).join(' ')}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-600 to-cyan-600 rounded-2xl p-8 text-white shadow-lg">
              <h3 className="text-2xl font-bold mb-4">Our Mission</h3>
              <p className="text-blue-50 leading-relaxed">
                To empower businesses with innovative technology solutions that transform challenges into opportunities and drive sustainable growth in the digital age.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default About;
